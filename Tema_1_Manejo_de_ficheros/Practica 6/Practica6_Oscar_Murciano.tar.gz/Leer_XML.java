package ficheros;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class Leer_XML {
	public static void main(String[] args) {
		try {
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document documento = builder.parse(new File("DAM_AD_UD01_P6_GOT_Ini.xml"));
			documento.getDocumentElement().normalize();			


			System.out.println("Elemento raiz: " + documento.getDocumentElement().getNodeName());
			NodeList personaje = documento.getElementsByTagName("character");


			for (int i = 0; i < personaje.getLength(); i++) {
				Node libro = personaje.item(i);
				if (libro.getNodeType() == Node.ELEMENT_NODE) {
					Element elemento = (Element) libro;
					Element playedBy = documento.createElement("PlayedBy");
					if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Arya Stark")){
						Text nombre = documento.createTextNode("Alfie Allen");
						playedBy.appendChild(nombre); 
					}
					else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Brandon  Stark")){
						Text nombre = documento.createTextNode("Isaac Hempstead-Wright");
						playedBy.appendChild(nombre); 
					}
					else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Rickon Stark")){
						Text nombre = documento.createTextNode("Art Parkinson");
						playedBy.appendChild(nombre); 
					}
					else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Robb Stark")){
						Text nombre = documento.createTextNode("Richard Madden");
						playedBy.appendChild(nombre); 
					}
					else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Sansa Stark")){
						Text nombre = documento.createTextNode("Sophie Turner");
						playedBy.appendChild(nombre); 
					}
					elemento.appendChild(playedBy);


					System.out.println(elemento.getElementsByTagName("name").item(0).getTextContent());

					System.out.println(elemento.getElementsByTagName("id").item(0).getNodeName()+
							"-"+ ((Element)(elemento.getElementsByTagName("id").item(0))).getAttribute("lang")+
							"-"+ elemento.getElementsByTagName("id").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("name").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("name").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("gender").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("gender").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("born").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("born").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("died").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("died").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("alive").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("alive").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("titles").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("titles").item(0).getTextContent());
				}

			}
			Element raiz = documento.createElement("character");
			documento.getDocumentElement().appendChild(raiz);
			Element elem = documento.createElement("id");
			Text text = documento.createTextNode("583"); 
			raiz.appendChild(elem); 
			elem.appendChild(text);
			Element elem2 = documento.createElement("name");
			Text text2 = documento.createTextNode("Jon Snow"); 
			raiz.appendChild(elem2); 
			elem2.appendChild(text2);
			Element elem3 = documento.createElement("born");
			Text text3 = documento.createTextNode("In 283 AC, at Winterfell"); 
			raiz.appendChild(elem3); 
			elem3.appendChild(text3);
			Element elem4 = documento.createElement("died");
			Text text4 = documento.createTextNode("True"); 
			raiz.appendChild(elem4); 
			elem4.appendChild(text4);
			Element elem5 = documento.createElement("titles");
			raiz.appendChild(elem5);
			Element elem6 = documento.createElement("title");
			Text text6 = documento.createTextNode("Lord Commander of the Night's Watch"); 
			elem5.appendChild(elem6); 
			elem6.appendChild(text6);
			Element elem7 = documento.createElement("title");
			Text text7 = documento.createTextNode("King in the North"); 
			elem5.appendChild(elem7); 
			elem7.appendChild(text7);
			Element elem8 = documento.createElement("alias");
			elem.appendChild(elem8); 
			Element elem9 = documento.createElement("alias");
			Text text9 = documento.createTextNode("Lord Snow"); 
			elem8.appendChild(elem9); 
			elem9.appendChild(text9);
			Element elem10 = documento.createElement("alias");
			Text text10 = documento.createTextNode("Ned Stark's Bastard"); 
			elem8.appendChild(elem10); 
			elem10.appendChild(text10);
			Element elem11 = documento.createElement("alias");
			Text text11 = documento.createTextNode("The Snow of Winterfell"); 
			elem8.appendChild(elem11); 
			elem11.appendChild(text11);
			Element elem12 = documento.createElement("alias");
			Text text12 = documento.createTextNode("The Crow-Come-Over");
			elem8.appendChild(elem12); 
			elem12.appendChild(text12);
			Element elem13 = documento.createElement("alias");
			Text text13 = documento.createTextNode("The 998th Lord Commander of the Night's Watch");
			elem8.appendChild(elem13); 
			elem13.appendChild(text13);
			Element elem14 = documento.createElement("alias");
			Text text14 = documento.createTextNode("The Bastard of Winterfell");
			elem8.appendChild(elem14); 
			elem14.appendChild(text14);
			Element elem15 = documento.createElement("alias");
			Text text15 = documento.createTextNode("The Black Bastard of the Wall");
			elem8.appendChild(elem15); 
			elem15.appendChild(text15);
			Element elem16 = documento.createElement("alias");
			Text text16 = documento.createTextNode("Lord Crow");
			elem8.appendChild(elem16); 
			elem16.appendChild(text16);
			Element elem17 = documento.createElement("libros");
			Text text17 = documento.createTextNode("todos");
			elem.appendChild(elem17); 
			elem17.appendChild(text17);
			Element elem18 = documento.createElement("temporadas");
			Text text18 = documento.createTextNode("todos");
			elem.appendChild(elem18); 
			elem18.appendChild(text18);
			Element elem19 = documento.createElement("Actor");
			Text text19 = documento.createTextNode("Kit Harington");
			elem.appendChild(elem19); 
			elem19.appendChild(text19);
			
			DOMImplementation implementation = builder.getDOMImplementation();

			Document documento2 = implementation.createDocument(null, "GOT", null);
			documento2.setXmlVersion("1.0");
			Source source = new DOMSource(documento2);
			Result result = new StreamResult(new File("GOT.xml"));
			Node importacion = documento2.importNode(documento.getDocumentElement(), true);
			documento2.getDocumentElement().appendChild(importacion);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.transform(source, result);


		} catch (Exception e) {
			System.err.println("Error: "+e.getMessage());
		}
	}


}
