package org.sfaci.gestionanimales.gui;

import org.sfaci.gestionanimales.base.Animal;
import org.sfaci.gestionanimales.util.Util;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;


public class VentanaController implements ActionListener, KeyListener {

    private final VentanaModel model;
    private final Ventana view;

    public VentanaController(VentanaModel model, Ventana view) {
        this.model = model;
        this.view = view;
        anadirActionListener(this);
        anadirKeyListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent event) {

        String actionCommand = event.getActionCommand();
        Animal animal;

        switch (actionCommand) {
            case "Nuevo":
                view.tfNombre.setText("");
                view.tfNombre.setEditable(true);
                view.tfCaracteristicas.setText("");
                view.tfCaracteristicas.setEditable(true);
                view.tfPeso.setText("");
                view.tfPeso.setEditable(true);
                view.tfRaza.setText("");
                view.tfRaza.setEditable(true);

                view.btGuardar.setEnabled(true);
                break;
            case "Guardar":
                try {
                    if (view.tfNombre.getText().equals("")) {
                        Util.mensajeError("El nombre es un campo obligatorio", "Nuevo Animal");
                        return;
                    }

                    animal = new Animal();
                    animal.setNombre(view.tfNombre.getText());
                    animal.setRaza(view.tfRaza.getText());
                    animal.setCaracteristicas(view.tfCaracteristicas.getText());
                    animal.setPeso(Float.parseFloat(view.tfPeso.getText()));

                    model.guardar(animal);

                    view.btGuardar.setEnabled(false);
                }  catch (NumberFormatException e) {
                    Util.mensajeError("El peso debe ser un numero","Error");
                }
                break;
            case "Modificar":
                if (view.tfNombre.getText().equals("")) {
                    Util.mensajeError("El nombre es un campo obligatorio", "Error Modificar Animal");
                    return;
                }
                if (view.tfRaza.getText().equals("")) {
                    Util.mensajeError("La raza es un campo obligatorio", "Error Modificar Animal");
                    return;
                }

                animal = new Animal();
                animal.setNombre(view.tfNombre.getText());
                animal.setRaza(view.tfRaza.getText());
                animal.setCaracteristicas(view.tfCaracteristicas.getText());
                animal.setPeso(Float.parseFloat(view.tfPeso.getText()));
                view.tfNombre.setEditable(true);
                view.tfPeso.setEditable(true);
                view.tfCaracteristicas.setEditable(true);
                view.tfRaza.setEditable(true);

                model.modificar(animal);
                break;
            case "Cancelar":
                view.tfNombre.setEditable(false);
                view.tfCaracteristicas.setEditable(false);
                view.tfPeso.setEditable(false);
                view.tfRaza.setEditable(false);

                animal = model.getActual();
                cargar(animal);

                view.btGuardar.setEnabled(false);
                break;
            case "Eliminar":
                try {
                    if (JOptionPane.showConfirmDialog(null, "¿Está seguro?", "Eliminar", JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
                        return;
                    view.tfNombre.setText("");
                    view.tfPeso.setText("");
                    view.tfCaracteristicas.setText("");
                    view.tfRaza.setText("");
                    view.btEliminar.setEnabled(false);
                    view.btModificar.setEnabled(false);
                    model.eliminar();
                    animal = model.getActual();
                    cargar(animal);
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }
                break;
            case "Buscar":
                animal = model.buscar(view.tfBusqueda.getText());
                if (animal == null) {
                    Util.mensajeInformacion("No se ha encontrado ningún animal con ese nombre", "Buscar");
                    return;
                }
                cargar(animal);
                break;
            case "Primero":
                try {
                    animal = model.getPrimero();
                    cargar(animal);
                    view.btEliminar.setEnabled(true);
                    view.btModificar.setEnabled(true);
                } catch (IndexOutOfBoundsException e) {}
                break;
            case "Anterior":
                try {
                    animal = model.getAnterior();
                    cargar(animal);
                    view.btEliminar.setEnabled(true);
                    view.btModificar.setEnabled(true);
                } catch (IndexOutOfBoundsException e) {}
                break;
            case "Siguiente":
                try {
                    animal = model.getSiguiente();
                    cargar(animal);
                    view.btEliminar.setEnabled(true);
                    view.btModificar.setEnabled(true);
                } catch (IndexOutOfBoundsException e) {}
                break;
            case "Ultimo":
                try {
                animal = model.getUltimo();
                cargar(animal);
                view.btEliminar.setEnabled(true);
                view.btModificar.setEnabled(true);
                } catch (IndexOutOfBoundsException e) {}
                break;
            case "Guardar_XML":
                if (view.tfNombre.getText().equals("")) {
                    Util.mensajeError("El nombre es un campo obligatorio", "Nuevo Animal");
                    return;
                }

                try {
                    model.guardarxml();
                } catch (TransformerException | ParserConfigurationException e) {
                    e.printStackTrace();
                }
                break;
            case "Leer_XML":
                try {
                    model.leerXml();
                } catch (ParserConfigurationException | IOException | SAXException e) {
                    e.printStackTrace();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

        if (e.getSource() == view.tfBusqueda) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                view.btBuscar.doClick();
            }
        }
    }

    private void cargar(Animal animal) {
        if (animal == null)
            return;

        view.tfNombre.setText(animal.getNombre());
        view.tfCaracteristicas.setText(animal.getCaracteristicas());
        view.tfRaza.setText(animal.getRaza());
        view.tfPeso.setText(String.valueOf(animal.getPeso()));
    }

    private void anadirKeyListener(KeyListener listener) {
        view.tfBusqueda.addKeyListener(listener);
    }

    private void anadirActionListener(ActionListener listener) {

        view.btNuevo.addActionListener(listener);
        view.btGuardar.addActionListener(listener);
        view.btModificar.addActionListener(listener);
        view.btEliminar.addActionListener(listener);
        view.btPrimero.addActionListener(listener);
        view.btAnterior.addActionListener(listener);
        view.btSiguiente.addActionListener(listener);
        view.btUltimo.addActionListener(listener);
        view.btBuscar.addActionListener(listener);
        view.guardarXMLButton.addActionListener(listener);
        view.leerXMLButton.addActionListener(listener);
    }
}
