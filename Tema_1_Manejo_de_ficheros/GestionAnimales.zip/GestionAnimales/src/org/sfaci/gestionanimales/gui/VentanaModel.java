package org.sfaci.gestionanimales.gui;

import org.sfaci.gestionanimales.base.Animal;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;



public class VentanaModel {

    private final ArrayList<Animal> listaAnimales;
    private int posicion;

    public VentanaModel() {
        listaAnimales = new ArrayList<>();
        posicion = 0;
    }


    public void guardar(Animal animal) {
            listaAnimales.add(animal);
            posicion++;


    }
    public void guardarxml() throws TransformerException, ParserConfigurationException {
        JFileChooser fc = new JFileChooser();
        String filename;
        fc.setDialogTitle("¿Donde quieres guardar el archivo?");
        fc.setSelectedFile(null);
        int opcion = fc.showSaveDialog(null);
            filename = fc.getSelectedFile().toString();


        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        //Elemento raíz
        Document doc = docBuilder.newDocument();
        Element rootElement = doc.createElement("Animales");
        doc.appendChild(rootElement);
        //Primer elemento
        for (Animal a : listaAnimales) {
            Element elemento1 = doc.createElement("Animal");
            rootElement.appendChild(elemento1);

            Element nombre = doc.createElement("Nombre");
            Text nombretxt = doc.createTextNode(a.getNombre());
            elemento1.appendChild(nombre);
            nombre.appendChild(nombretxt);

            Element raza = doc.createElement("Raza");
            Text razatxt = doc.createTextNode(a.getRaza());
            elemento1.appendChild(raza);
            raza.appendChild(razatxt);

            Element caracteristicas = doc.createElement("Caracteristicas");
            Text caracteristicastxt = doc.createTextNode(a.getCaracteristicas());
            elemento1.appendChild(caracteristicas);
            caracteristicas.appendChild(caracteristicastxt);

            Element peso = doc.createElement("Peso");
            Text pesotxt = doc.createTextNode(""+ a.getPeso());
            elemento1.appendChild(peso);
            peso.appendChild(pesotxt);
        }

        //Se escribe el contenido del XML en un archivo
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result;
        if (!filename .endsWith(".xml")) {
            filename += ".xml";
             result = new StreamResult(new File(filename));
        } else {
             result = new StreamResult(new File(filename));
        }
        transformer.transform(source, result);

    }
    public void leerXml() throws ParserConfigurationException, IOException, SAXException {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Selecciona el fichero a leer");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("XML File","xml");
        fc.setAcceptAllFileFilterUsed(false);
        fc.setFileFilter(filter);
       // fc.addChoosableFileFilter(filter);
        fc.setSelectedFile(null);
        int opcion = fc.showOpenDialog(null);
        if (opcion != JFileChooser.APPROVE_OPTION)
            return;
        File f = fc.getSelectedFile();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document documento = builder.parse(f);
        documento.getDocumentElement().normalize();
        NodeList animales = documento.getElementsByTagName("Animal");
        for (int i = 0; i < animales.getLength(); i++) {
            Node nodo = animales.item(i);
            if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                Element e = (Element) nodo;
                Animal animal = new Animal();
                animal.setNombre(e.getElementsByTagName("Nombre").item(0).getTextContent());
                animal.setRaza(e.getElementsByTagName("Raza").item(0).getTextContent());
                animal.setCaracteristicas(e.getElementsByTagName("Caracteristicas").item(0).getTextContent());
                animal.setPeso(Float.parseFloat(e.getElementsByTagName("Peso").item(0).getTextContent()));
                listaAnimales.add(animal);
            }
        }
    }


    /**
     * Modifica los datos del animal actual
     */
    public void modificar(Animal animalModificado) {

        Animal animal = listaAnimales.get(posicion);
        animal.setNombre(animalModificado.getNombre());
        animal.setCaracteristicas(animalModificado.getCaracteristicas());
        animal.setRaza(animalModificado.getRaza());
        animal.setPeso(animalModificado.getPeso());
    }

    /**
     * Elimina el animal actual
     */
    public void eliminar() {
        listaAnimales.remove(posicion);
    }

    public Animal getActual() {

        return listaAnimales.get(posicion);
    }

    /**
     * Busca un animal en la lista
     * @param nombre El nombre del animal
     * @return El animal o null si no se ha encontrado nada
     */
    public Animal buscar(String nombre) {
        for (Animal animal : listaAnimales) {
            if (animal.getNombre().equals(nombre)) {
                return animal;
            }
        }

        return null;
    }

    /**
     * Obtiene el animal que está en primera posición en la lista
     */
    public Animal getPrimero() {

        posicion = 0;
        return listaAnimales.get(posicion);
    }

    /**
     * Obtiene el animal que está en la posición anterior a la actual
     */
    public Animal getAnterior() {

        if (posicion == 0)
            return null;

        posicion--;
        return listaAnimales.get(posicion);
    }

    /**
     * Obtiene el animal que está en la posición siguiente a la actual
     */
    public Animal getSiguiente() {

        if (posicion == listaAnimales.size() - 1)
            return null;

        posicion++;
        return listaAnimales.get(posicion);
    }

    /**
     * Obtiene el animal que está en la última posición de la lista
     */
    public Animal getUltimo() {

        posicion = listaAnimales.size() - 1;
        return listaAnimales.get(posicion);
    }
}
